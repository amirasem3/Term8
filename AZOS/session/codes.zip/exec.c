#include <stdio.h>
#include <unistd.h>

int main() {
    char *binaryPath = "/bin/ls";
    char *arg1 = "-g";
    char *arg2 = "-h";

    execl(binaryPath, binaryPath, arg1, arg2, NULL);

    return 0;
}

