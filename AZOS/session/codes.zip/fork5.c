#include <stdio.h>
#include <unistd.h>

int main() {
  fork();
    fork();
    printf("process %d Parent Process ID is %d\n", getpid() , getppid());
    return 0;
}

