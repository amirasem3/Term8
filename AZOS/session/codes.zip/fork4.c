#include <stdio.h> 
#include <unistd.h>

int main() {

	 printf("Hello World! , performed in %d and his father is %d \n" ,getpid() , getppid());
    printf("* fork performed in %d and his father is %d \n " , getpid() , getppid()) ;fork();
    printf("I am after first forking , performed in %d and his father is %d \n" , getpid() , getppid());
    printf("** fork performed in %d and his father is %d \n " , getpid() , getppid());fork();
    printf("I am after second forking , performed in %d and his father is %d \n" , getpid() , getppid());
    printf("*** fork performed in %d and his father is %d \n " , getpid() , getppid());fork();
    printf("I am after third forking , performed in %d and his father is %d \n" , getpid() , getppid());
    printf("\tI am process %d.performed in %d and his father is %d \n", getpid() , getpid() , getppid());
    printf("performed in %d and his father is %d \n" , getpid() , getppid());return 0;
}
