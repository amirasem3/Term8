#include <stdio.h>
#include <unistd.h>

int main() {
	
	printf("Hello World!\n");
	int pid = fork();
	if(pid ==0 ) {
	printf("I am child \n");
	}
	else{
	printf("I am parent \n");
	}
	printf("I am after forking\n"); 
	printf("\tI am process %d.\n", getpid()); 
	return 0;
}
