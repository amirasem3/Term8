#include<stdio.h> 
#include<stdlib.h> 
#include<sys/wait.h> 
#include<unistd.h>

int main(){
printf("This is parrent (pid : %d) with parent ID : %d \n" , getpid(), getppid());
int pid; 
pid = fork();
int stat; 

if(pid==0){
   printf("Enter child process (pid : %d) with parent ID : %d \n" ,getpid() , getppid());
	sleep(5);
   printf("In child process (pid : %d) with parent ID : %d after sleep\n " , getpid() , getppid());
}
else {
printf("we are in parent process with ID : %d \n" , getpid());
}
printf("process %d has been ended \n" , getpid());
return 0 ;
}
