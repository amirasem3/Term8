#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
  pid_t pid;
  int status;
  if ((pid = fork()) < 0)
    perror("fork() error");
  else if (pid == 0) {
    printf("child (pid %d) started ... \n", (int) getpid());
    for (int i = 0 ; i < 100 ; i++){
	printf("%d " " " , i);
	}
	printf("\n");
    printf("child (pid %d)  exiting \n" , (int) getpid());
    exit(1);
  }
  else {
    printf("parent (pid : %d) has forked child with pid of %d\n", getpid(),(int) pid);
    printf("parent is starting wait ...\n");
    if ((pid = wait(&status)) == -1)
      perror("wait() error");
    else {
      printf("child work has been done \n");
      printf("parent is done waiting \n ");
      printf("the pid of the process that ended was %d\n", (int) pid);
      if (WIFEXITED(status))
        printf("child exited with status of %d\n", WEXITSTATUS(status));
    }
  }
return 0 ;
}
